@echo off
start "" "%~dp0QuarryDays.exe" -- --terrain-arena
