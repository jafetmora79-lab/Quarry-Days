@echo off
start "" "%~dp0QuarryDays.exe" res://TerrainArena.tscn
