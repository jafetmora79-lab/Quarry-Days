Quarry Days - Windows build (branch claude/quarry-repair, Phase 8.3 Industrial Hub and Employee Experience, commit daf8421).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
