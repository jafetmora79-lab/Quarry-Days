Quarry Days - Windows build (branch claude/quarry-phase-9-progression, Phase 9 + 3D assets, commit 282186e).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
