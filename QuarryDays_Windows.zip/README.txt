Quarry Days - Windows build (branch claude/quarry-open-pit-reconstruction, Phase 8.7 Open-Pit Quarry, commit 59b1255).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
