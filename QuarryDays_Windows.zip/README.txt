Quarry Days - Windows build (branch claude/quarry-repair, Phase 8.1 Quarry Safety, commit 243b5e2).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
