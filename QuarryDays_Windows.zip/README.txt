Quarry Days - Windows build (branch claude/quarry-phase-10-geological-mining, Phase 10.1-10.2 + progression, commit 88b9a2e).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
