Quarry Days - Windows build (branch claude/quarry-repair, Phase 8.4 revision, commit a6873e5).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
