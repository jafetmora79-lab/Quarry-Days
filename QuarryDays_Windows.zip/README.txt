Quarry Days - Windows build (branch claude/quarry-master-overhaul, Phase 7.4).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
