Quarry Days - Windows build (branch claude/quarry-repair, Phase 8.4 HUD and Purchase Experience, commit 244145c).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
