Quarry Days - Windows build (branch claude/quarry-phase-9-6-equipment, Phase 9.6 equipment, commit 24abc3a).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
