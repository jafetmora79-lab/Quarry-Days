Quarry Days - Windows build (branch claude/quarry-repair, Phase 8.2 Mining and Industrial Progression, commit 829ad6d).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
