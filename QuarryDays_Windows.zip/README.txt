Quarry Days - Windows build (branch claude/quarry-phase-9-progression, Phase 9 Progression, commit 1926fa8).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
