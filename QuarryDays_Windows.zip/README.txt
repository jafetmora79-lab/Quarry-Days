Quarry Days - Windows build (branch claude/quarry-repair, Phase 8.5 Production and Visual Polish, commit 72cd4a7).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
