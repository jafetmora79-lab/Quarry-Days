Quarry Days - Windows build (branch claude/quarry-phase-9-5-integration, Phase 9.5 integration of 8.7 + 9, commit bbd560e).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
