Quarry Days - Windows build (branch claude/quarry-repair, Phase 8.6 Story and Late-Game Quality, commit 17c1d2f).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
