Quarry Days - Windows build (branch claude/quarry-phase-9-7-final-integration, commit 7789d9e).
Unzip, keep QuarryDays.exe and QuarryDays.pck together, run the EXE.
