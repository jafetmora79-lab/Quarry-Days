QUARRY DAYS - ENVIRONMENT POLISH

Extract all files together. Launch QuarryDays.exe on Windows x64. Keep QuarryDays.pck beside it.

Source branch: codex/quarry-environment-polish
Base: claude/quarry-exact-blueprint / ed9e3945
Engine: Godot 4.3-stable, GL Compatibility

MACHINERY ORDERS is beside the workshop, east of its front entrance. Look at the terminal screen and press E.
Walking: 5.25 m/s; sprint: 7.5 m/s (both +25%).

18 automated suites / 377 checks passed. EXE boot tested headlessly under Wine 10; native Windows graphics and performance await visual QA.
No screenshots, videos or renders were generated. Existing gameplay data, progression, save implementation and worker/vehicle assets are unchanged.

See ENVIRONMENT_POLISH.md for changes, test details and known baseline headless renderer diagnostics.
